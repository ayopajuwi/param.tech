'use strict';

$(document).ready(function () {
    const currentYear = new Date().getFullYear();
    $('#current-year').text(currentYear);
});